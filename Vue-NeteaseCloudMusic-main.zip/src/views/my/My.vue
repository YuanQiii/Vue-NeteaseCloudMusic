<template>
  <div>My</div>
</template>

<script>
export default {
  name: "My",
};
</script>

<style>
</style>