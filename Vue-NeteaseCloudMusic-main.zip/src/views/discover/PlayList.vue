<template>
  <div>PlayList</div>
</template>

<script>
export default {
  name: "PlayList",
};
</script>

<style>
</style>