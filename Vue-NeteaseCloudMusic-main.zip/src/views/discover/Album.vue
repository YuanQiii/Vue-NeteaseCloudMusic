<template>
  <div>Album</div>
</template>

<script>
export default {
  name: "Album",
};
</script>

<style>
</style>