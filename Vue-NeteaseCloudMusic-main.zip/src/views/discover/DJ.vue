<template>
  <div>DJ</div>
</template>

<script>
export default {
  name: "DJ",
};
</script>

<style>
</style>