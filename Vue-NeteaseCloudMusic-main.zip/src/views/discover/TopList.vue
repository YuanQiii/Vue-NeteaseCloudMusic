<template>
  <div>TopList</div>
</template>

<script>
export default {
  name: "TopList",
};
</script>

<style>
</style>