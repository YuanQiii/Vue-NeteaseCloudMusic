<template>
  <div>Artist</div>
</template>

<script>
export default {
  name: "Artist",
};
</script>

<style>
</style>