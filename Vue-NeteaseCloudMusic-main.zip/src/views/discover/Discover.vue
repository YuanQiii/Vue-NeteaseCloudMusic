<template>
  <div class="discover">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "Discover",
};
</script>

<style lang="scss" scoped>
.discover {
  display: flex;
  justify-content: center;
}
</style>