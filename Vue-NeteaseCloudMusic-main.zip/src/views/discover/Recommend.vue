<template>
  <div>
    <banner />
  </div>
</template>

<script>
import Banner from "../../components/recommend/Banner.vue";

export default {
  components: { Banner },
  name: "Recommend",
};
</script>

<style></style>
