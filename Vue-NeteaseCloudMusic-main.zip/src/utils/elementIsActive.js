export function elementIsActive(current, self) {
    return current == self ? 'active' : 'deactive'
}